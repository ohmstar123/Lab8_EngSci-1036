public class Cat extends Animal{

    //Public String method that returns what a cat says
    public String say(){
        return "meow-meow";
    }
}
