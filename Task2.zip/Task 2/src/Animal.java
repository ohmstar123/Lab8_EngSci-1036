public class Animal {

    //Public String method that returns nothing
    public String say(){
        return "";
    }


}
