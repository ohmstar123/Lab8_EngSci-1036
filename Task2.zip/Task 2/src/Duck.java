public class Duck extends Animal{

    //Public String method that returns what a duck says
    public String say(){
        return "quack-quack";
    }
}
