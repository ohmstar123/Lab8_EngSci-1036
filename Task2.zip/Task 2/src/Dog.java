public class Dog extends Animal{

    //Public String method that returns what a dog says
    public String say(){
        return "arf-arf";
    }
}
